The application PayementTracker was developed under IDE Eclipse Mars, java 1.7 according to specification of company BSC

Application can be run from runnable jar file by typing: java -jar PayementTracker.jar

Rules to run the application:
Application is running till users types quit.
When there is made error in typing, error message is displayed and application keeps on running.
When there is made error in file parsing, error message is displayed, marking row number with wrong record and application keeps on running.
When there is a fatal error, error message is displayed and application quit.

Made on 9th March 2016 by Ludvik Valicek
